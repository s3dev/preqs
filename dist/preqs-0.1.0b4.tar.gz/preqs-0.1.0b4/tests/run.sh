#!/usr/bin/env bash

# Run tests.
printf "\nRunning unit tests ..."
python -m unittest discover
printf "\nTesting complete.\n\n"

