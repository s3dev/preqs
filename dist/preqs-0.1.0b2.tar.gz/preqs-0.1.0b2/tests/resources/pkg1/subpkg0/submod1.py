
# No import statements here.

class Things:
    pass

things = Things()

